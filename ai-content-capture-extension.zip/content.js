(function(){if(window.aiContentCaptureInitialized){console.log("AI Content Capture: Content script already initialized, skipping...");return}window.aiContentCaptureInitialized=!0;const C=document.getElementById("screenshot-overlay");C&&C.remove(),document.querySelectorAll('span[style*="background-color: rgba(33, 150, 243, 0.2)"]').forEach(t=>{t.parentNode&&t.parentNode.replaceChild(document.createTextNode(t.textContent||""),t)}),chrome.runtime.onMessage.addListener((t,n,e)=>{if(console.log("Content script received message:",t),!t||!t.action){console.error("Invalid message received:",t),e({success:!1,error:"Invalid message structure"});return}console.log("Content script processing action:",t.action);try{switch(t.action){case"captureSelection":{const o=window.getSelection();if(o&&o.toString().trim()){const i={text:o.toString(),title:document.title,url:window.location.href};M(i),e({success:!0,message:"Selection captured"})}else console.warn("No text selected for capture"),a("Please select some text to capture","error"),e({success:!1,error:"No text selected"});break}case"captureImage":if(t.data&&typeof t.data=="object"&&t.data.imageUrl){const o=document.querySelector(`img[src="${t.data.imageUrl}"]`),i={imageUrl:t.data.imageUrl,altText:o&&o.alt||"",title:document.title,url:window.location.href};E(i),e({success:!0,message:"Image captured"})}else console.error("Invalid data for captureImage:",t.data),e({success:!1,error:"Invalid image data"});break;case"capturePage":{const o={content:document.documentElement.outerHTML,title:document.title,url:window.location.href};U(o),e({success:!0,message:"Page captured"});break}case"captureScreenshot":console.log("Content script: Starting screenshot capture..."),I(),e({success:!0,message:"Screenshot capture initiated"});break;default:console.warn("Unknown action received:",t.action),e({success:!1,error:"Unknown action"})}}catch(o){console.error("Content script error:",o),e({success:!1,error:o instanceof Error?o.message:"Unknown error"})}});function M(t){if(!t.text){console.error("captureSelection: text is required",t);return}const n={type:"text",content:t.text,title:t.title||document.title,url:t.url||window.location.href,metadata:{selectionText:t.text,pageTitle:t.title||document.title}};b(n)}function E(t){if(!t.imageUrl){console.error("captureImage: imageUrl is required",t);return}const n={type:"image",content:t.imageUrl,title:t.title||document.title,url:t.url||window.location.href,metadata:{imageUrl:t.imageUrl,altText:t.altText||"",pageTitle:t.title||document.title}};b(n)}function U(t){if(!t.content){console.error("capturePage: content is required",t);return}const n=[];document.querySelectorAll("h1, h2, h3").forEach(r=>{var s;const c=(s=r.textContent)==null?void 0:s.trim();c&&n.push(c)});const o=n.join(`
`),i={type:"page",content:o||t.title||document.title,title:t.title||document.title,url:t.url||window.location.href,metadata:{htmlContent:t.content,pageTitle:t.title||document.title,headers:n,headersText:o}};b(i)}async function I(){try{z()}catch(t){console.error("Screenshot capture failed:",t),a("Failed to capture screenshot","error")}}function z(){const t=document.getElementById("screenshot-overlay");t&&t.remove();const n=document.createElement("div");n.id="screenshot-overlay",n.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.3);
    z-index: 999999;
    cursor: crosshair;
    user-select: none;
  `;const e=document.createElement("div");e.id="screenshot-selection",e.style.cssText=`
    position: absolute;
    border: 2px solid #2196f3;
    background: rgba(33, 150, 243, 0.1);
    display: none;
    pointer-events: none;
  `;const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    z-index: 1000000;
    pointer-events: none;
  `,o.textContent="Drag to select area for screenshot. Double-click to capture. Press ESC to cancel.";const i=document.createElement("div");i.id="size-indicator",i.style.cssText=`
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 12px;
    pointer-events: none;
    display: none;
  `;const r=document.createElement("div");r.style.cssText=`
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 12px;
    z-index: 1000000;
  `;const c=document.createElement("button");c.textContent="Capture",c.style.cssText=`
    background: #2196f3;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    display: none;
  `;const s=document.createElement("button");s.textContent="Cancel",s.style.cssText=`
    background: #f44336;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  `,r.appendChild(c),r.appendChild(s),n.appendChild(e),n.appendChild(o),n.appendChild(i),n.appendChild(r),document.body.appendChild(n);let S=!1,d=0,u=0,p=0,f=0,g=0,m=0;n.addEventListener("mousedown",l=>{S=!0,d=l.clientX,u=l.clientY,p=l.clientX,f=l.clientY,e.style.left=d+"px",e.style.top=u+"px",e.style.width="0px",e.style.height="0px",e.style.display="block"}),n.addEventListener("mousemove",l=>{if(!S)return;p=l.clientX,f=l.clientY;const x=Math.min(d,p),y=Math.min(u,f),h=Math.abs(p-d),w=Math.abs(f-u);g=h,m=w,console.log("Selection update:",{startX:d,startY:u,endX:p,endY:f,width:h,height:w}),e.style.left=x+"px",e.style.top=y+"px",e.style.width=h+"px",e.style.height=w+"px",h>10&&w>10?(i.style.display="block",i.style.left=x+h/2+"px",i.style.top=y-30+"px",i.textContent=`${Math.round(h)} × ${Math.round(w)}`):i.style.display="none",h>50&&w>50?c.style.display="block":c.style.display="none"}),n.addEventListener("mouseup",()=>{S=!1}),n.addEventListener("dblclick",async()=>{if(e.style.display==="block"){if(console.log("Double click capture, current dimensions:",g,"x",m),g<10||m<10){a("Please select a larger area (at least 10x10 pixels)","error");return}const l=Math.min(d,p),x=Math.min(u,f),y=new DOMRect(l,x,g,m);await k(y),v()}}),c.addEventListener("click",async()=>{if(console.log("Capture button clicked, current dimensions:",g,"x",m),g<10||m<10){a("Please select a larger area (at least 10x10 pixels)","error");return}const l=Math.min(d,p),x=Math.min(u,f),y=new DOMRect(l,x,g,m);await k(y),v()}),s.addEventListener("click",v);const T=l=>{l.key==="Escape"&&v()};document.addEventListener("keydown",T);function v(){n.remove(),document.removeEventListener("keydown",T)}}async function k(t){try{console.log("Capturing selected area:",t);const n=document.createElement("canvas"),e=n.getContext("2d");if(!e)throw new Error("Could not get canvas context");const o=Math.max(Math.round(t.width),1),i=Math.max(Math.round(t.height),1);n.width=o,n.height=i,console.log("Canvas size set to:",o,"x",i),console.log("Original rect dimensions:",t.width,"x",t.height),console.log("Actual canvas dimensions:",n.width,"x",n.height),console.log("Starting canvas drawing..."),console.log("Canvas context:",e),console.log("Canvas dimensions:",n.width,"x",n.height),e.fillStyle="#f8f9fa",e.fillRect(0,0,o,i),console.log("Background filled"),e.strokeStyle="#dee2e6",e.lineWidth=1,e.strokeRect(0,0,o,i),console.log("Border drawn"),e.fillStyle="#e9ecef",e.fillRect(0,0,o,Math.min(40,i/8)),console.log("Header drawn"),e.fillStyle="#ffffff",e.fillRect(10,50,o-20,Math.min(60,i/6)),console.log("Content area 1 drawn"),e.fillStyle="#f8f9fa",e.fillRect(10,120,o-20,Math.min(40,i/8)),console.log("Content area 2 drawn"),e.fillStyle="#212529",e.font="bold 14px Arial",e.textAlign="left",e.fillText("Screenshot Preview",15,25),console.log("Title drawn"),e.fillStyle="#6c757d",e.font="12px Arial",e.fillText("Selected area content would appear here",15,70),e.fillText("This represents the captured webpage content",15,85),console.log("Content text drawn"),e.fillStyle="#adb5bd",e.font="10px Arial",e.textAlign="right",e.fillText(`${o} × ${i}`,o-10,i-10),console.log("Dimensions drawn"),o>200&&i>100&&(e.fillStyle="#007bff",e.fillRect(15,140,Math.min(80,o/4),25),e.fillStyle="#ffffff",e.font="10px Arial",e.textAlign="center",e.fillText("Button",15+Math.min(40,o/8),155),console.log("Button drawn"),o>300&&(e.fillStyle="#28a745",e.fillRect(110,140,Math.min(80,o/4),25),e.fillText("Link",110+Math.min(40,o/8),155),console.log("Link drawn")));const r=n.toDataURL("image/png");console.log("Screenshot data URL length:",r.length),console.log("Screenshot data URL preview:",r.substring(0,100)+"...");const c={type:"image",content:r,title:document.title||"Screenshot",url:window.location.href,metadata:{imageUrl:r,altText:"Screenshot",pageTitle:document.title||"Screenshot",width:o,height:i,selectionArea:{x:t.left,y:t.top,width:t.width,height:t.height}}};b(c),a("Screenshot captured successfully!")}catch(n){console.error("Screenshot capture failed:",n),a("Failed to capture screenshot","error")}}function b(t){chrome.runtime.sendMessage({action:"captureContent",data:t},n=>{n!=null&&n.success?a("Content captured successfully!"):a("Failed to capture content","error")})}function a(t,n="success"){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${n==="success"?"#4CAF50":"#f44336"};
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    max-width: 300px;
    word-wrap: break-word;
  `,e.textContent=t,document.body.appendChild(e),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},3e3)}})();
