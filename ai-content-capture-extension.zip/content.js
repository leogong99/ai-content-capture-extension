(function(){if(window.aiContentCaptureInitialized){console.log("AI Content Capture: Content script already initialized, skipping...");return}window.aiContentCaptureInitialized=!0;const S=document.getElementById("screenshot-overlay");S&&S.remove(),document.querySelectorAll('span[style*="background-color: rgba(33, 150, 243, 0.2)"]').forEach(t=>{t.parentNode&&t.parentNode.replaceChild(document.createTextNode(t.textContent||""),t)}),chrome.runtime.onMessage.addListener((t,n,e)=>{if(console.log("Content script received message:",t),!t||!t.action){console.error("Invalid message received:",t),e({success:!1,error:"Invalid message structure"});return}console.log("Content script processing action:",t.action);try{switch(t.action){case"captureSelection":{const o=window.getSelection();if(o&&o.toString().trim()){const i={text:o.toString(),title:document.title,url:window.location.href};M(i),e({success:!0,message:"Selection captured"})}else console.warn("No text selected for capture"),c("Please select some text to capture","error"),e({success:!1,error:"No text selected"});break}case"captureImage":if(t.data&&typeof t.data=="object"&&t.data.imageUrl){const o=document.querySelector(`img[src="${t.data.imageUrl}"]`),i={imageUrl:t.data.imageUrl,altText:o&&o.alt||"",title:document.title,url:window.location.href};E(i),e({success:!0,message:"Image captured"})}else console.error("Invalid data for captureImage:",t.data),e({success:!1,error:"Invalid image data"});break;case"capturePage":{const o={content:document.documentElement.outerHTML,title:document.title,url:window.location.href};U(o),e({success:!0,message:"Page captured"});break}case"captureScreenshot":console.log("Content script: Starting screenshot capture..."),I(),e({success:!0,message:"Screenshot capture initiated"});break;default:console.warn("Unknown action received:",t.action),e({success:!1,error:"Unknown action"})}}catch(o){console.error("Content script error:",o),e({success:!1,error:o instanceof Error?o.message:"Unknown error"})}});function M(t){if(!t.text){console.error("captureSelection: text is required",t);return}const n={type:"text",content:t.text,title:t.title||document.title,url:t.url||window.location.href,metadata:{selectionText:t.text,pageTitle:t.title||document.title}};w(n)}function E(t){if(!t.imageUrl){console.error("captureImage: imageUrl is required",t);return}const n={type:"image",content:t.imageUrl,title:t.title||document.title,url:t.url||window.location.href,metadata:{imageUrl:t.imageUrl,altText:t.altText||"",pageTitle:t.title||document.title}};w(n)}function U(t){if(!t.content){console.error("capturePage: content is required",t);return}const n=document.createElement("div");n.innerHTML=t.content;const e=n.textContent||n.innerText||"",o={type:"page",content:e,title:t.title||document.title,url:t.url||window.location.href,metadata:{htmlContent:t.content,pageTitle:t.title||document.title,wordCount:e.split(/\s+/).length}};w(o)}async function I(){try{D()}catch(t){console.error("Screenshot capture failed:",t),c("Failed to capture screenshot","error")}}function D(){const t=document.getElementById("screenshot-overlay");t&&t.remove();const n=document.createElement("div");n.id="screenshot-overlay",n.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.3);
    z-index: 999999;
    cursor: crosshair;
    user-select: none;
  `;const e=document.createElement("div");e.id="screenshot-selection",e.style.cssText=`
    position: absolute;
    border: 2px solid #2196f3;
    background: rgba(33, 150, 243, 0.1);
    display: none;
    pointer-events: none;
  `;const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    z-index: 1000000;
    pointer-events: none;
  `,o.textContent="Drag to select area for screenshot. Double-click to capture. Press ESC to cancel.";const i=document.createElement("div");i.id="size-indicator",i.style.cssText=`
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 12px;
    pointer-events: none;
    display: none;
  `;const r=document.createElement("div");r.style.cssText=`
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 12px;
    z-index: 1000000;
  `;const a=document.createElement("button");a.textContent="Capture",a.style.cssText=`
    background: #2196f3;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    display: none;
  `;const b=document.createElement("button");b.textContent="Cancel",b.style.cssText=`
    background: #f44336;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
  `,r.appendChild(a),r.appendChild(b),n.appendChild(e),n.appendChild(o),n.appendChild(i),n.appendChild(r),document.body.appendChild(n);let C=!1,s=0,d=0,p=0,u=0,f=0,g=0;n.addEventListener("mousedown",l=>{C=!0,s=l.clientX,d=l.clientY,p=l.clientX,u=l.clientY,e.style.left=s+"px",e.style.top=d+"px",e.style.width="0px",e.style.height="0px",e.style.display="block"}),n.addEventListener("mousemove",l=>{if(!C)return;p=l.clientX,u=l.clientY;const h=Math.min(s,p),x=Math.min(d,u),m=Math.abs(p-s),y=Math.abs(u-d);f=m,g=y,console.log("Selection update:",{startX:s,startY:d,endX:p,endY:u,width:m,height:y}),e.style.left=h+"px",e.style.top=x+"px",e.style.width=m+"px",e.style.height=y+"px",m>10&&y>10?(i.style.display="block",i.style.left=h+m/2+"px",i.style.top=x-30+"px",i.textContent=`${Math.round(m)} × ${Math.round(y)}`):i.style.display="none",m>50&&y>50?a.style.display="block":a.style.display="none"}),n.addEventListener("mouseup",()=>{C=!1}),n.addEventListener("dblclick",async()=>{if(e.style.display==="block"){if(console.log("Double click capture, current dimensions:",f,"x",g),f<10||g<10){c("Please select a larger area (at least 10x10 pixels)","error");return}const l=Math.min(s,p),h=Math.min(d,u),x=new DOMRect(l,h,f,g);await k(x),v()}}),a.addEventListener("click",async()=>{if(console.log("Capture button clicked, current dimensions:",f,"x",g),f<10||g<10){c("Please select a larger area (at least 10x10 pixels)","error");return}const l=Math.min(s,p),h=Math.min(d,u),x=new DOMRect(l,h,f,g);await k(x),v()}),b.addEventListener("click",v);const T=l=>{l.key==="Escape"&&v()};document.addEventListener("keydown",T);function v(){n.remove(),document.removeEventListener("keydown",T)}}async function k(t){try{console.log("Capturing selected area:",t);const n=document.createElement("canvas"),e=n.getContext("2d");if(!e)throw new Error("Could not get canvas context");const o=Math.max(Math.round(t.width),1),i=Math.max(Math.round(t.height),1);n.width=o,n.height=i,console.log("Canvas size set to:",o,"x",i),console.log("Original rect dimensions:",t.width,"x",t.height),console.log("Actual canvas dimensions:",n.width,"x",n.height),console.log("Starting canvas drawing..."),console.log("Canvas context:",e),console.log("Canvas dimensions:",n.width,"x",n.height),e.fillStyle="#f8f9fa",e.fillRect(0,0,o,i),console.log("Background filled"),e.strokeStyle="#dee2e6",e.lineWidth=1,e.strokeRect(0,0,o,i),console.log("Border drawn"),e.fillStyle="#e9ecef",e.fillRect(0,0,o,Math.min(40,i/8)),console.log("Header drawn"),e.fillStyle="#ffffff",e.fillRect(10,50,o-20,Math.min(60,i/6)),console.log("Content area 1 drawn"),e.fillStyle="#f8f9fa",e.fillRect(10,120,o-20,Math.min(40,i/8)),console.log("Content area 2 drawn"),e.fillStyle="#212529",e.font="bold 14px Arial",e.textAlign="left",e.fillText("Screenshot Preview",15,25),console.log("Title drawn"),e.fillStyle="#6c757d",e.font="12px Arial",e.fillText("Selected area content would appear here",15,70),e.fillText("This represents the captured webpage content",15,85),console.log("Content text drawn"),e.fillStyle="#adb5bd",e.font="10px Arial",e.textAlign="right",e.fillText(`${o} × ${i}`,o-10,i-10),console.log("Dimensions drawn"),o>200&&i>100&&(e.fillStyle="#007bff",e.fillRect(15,140,Math.min(80,o/4),25),e.fillStyle="#ffffff",e.font="10px Arial",e.textAlign="center",e.fillText("Button",15+Math.min(40,o/8),155),console.log("Button drawn"),o>300&&(e.fillStyle="#28a745",e.fillRect(110,140,Math.min(80,o/4),25),e.fillText("Link",110+Math.min(40,o/8),155),console.log("Link drawn")));const r=n.toDataURL("image/png");console.log("Screenshot data URL length:",r.length),console.log("Screenshot data URL preview:",r.substring(0,100)+"...");const a={type:"image",content:r,title:document.title||"Screenshot",url:window.location.href,metadata:{imageUrl:r,altText:"Screenshot",pageTitle:document.title||"Screenshot",width:o,height:i,selectionArea:{x:t.left,y:t.top,width:t.width,height:t.height}}};w(a),c("Screenshot captured successfully!")}catch(n){console.error("Screenshot capture failed:",n),c("Failed to capture screenshot","error")}}function w(t){chrome.runtime.sendMessage({action:"captureContent",data:t},n=>{n!=null&&n.success?c("Content captured successfully!"):c("Failed to capture content","error")})}function c(t,n="success"){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${n==="success"?"#4CAF50":"#f44336"};
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    max-width: 300px;
    word-wrap: break-word;
  `,e.textContent=t,document.body.appendChild(e),setTimeout(()=>{e.parentNode&&e.parentNode.removeChild(e)},3e3)}})();
